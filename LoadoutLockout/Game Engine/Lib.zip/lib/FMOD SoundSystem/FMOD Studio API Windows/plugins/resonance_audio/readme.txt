# Resonance Audio SDK for [FMOD](http://www.fmod.com) v1.0

Enables high-quality spatial audio on mobile and desktop platforms.

To get started read the online [documentation](https://developers.google.com/resonance-audio/develop/fmod/getting-started).

Copyright (c) 2017 Google Inc. All rights reserved.